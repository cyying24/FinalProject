//
//  StatisticsComponentView.swift
//  FinalProject
//
//  Created by Curtis Yucheng Ying24 on 5/22/23.
//

import SwiftUI

struct StatisticsComponentView: View {
    //Declare constants
    let selectedTimeFilter: String
    let image: String
    let imageColor: Color
    let activity: String
    let averageHoursOrRating: Double
    var body: some View {
        VStack {
            Image(systemName: image)
                .foregroundColor(imageColor)
                .font(.largeTitle)
                .frame(height: 40)
            if activity != "" {
                Text("Your average hours of \(activity) for \(selectedTimeFilter) was")
                    .font(.system(.body, design: .rounded))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 10)
                    .fontWeight(.semibold)
                Text(String(format: "%.2f Hours", averageHoursOrRating))
                    .font(.system(.title, design: .rounded))
                    .bold()
                    .padding(.vertical, 5)
            } else {
                Text("Your average day rating for \(selectedTimeFilter) was")
                    .font(.system(.body, design: .rounded))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 10)
                Text(String(format: "%.2f out of 100", averageHoursOrRating))
                    .font(.system(.title, design: .rounded))
                    .bold()
                    .padding(.vertical, 5)
            }
            
            VStack {
                if activity == "sleep" && averageHoursOrRating < 8 {
                    Text("It is recommended for you to get more sleep. Try going to bed earlier or waking up later!")
                        .foregroundColor(.red.opacity(0.75))
                } else if activity == "exercise" && averageHoursOrRating < 1 {
                    Text("It is recommended for you to get more exercise. Try taking a walk after a meal or participating in a sport!")
                        .foregroundColor(.red.opacity(0.75))
                } else if activity == "homework" && averageHoursOrRating > 5 {
                    Text("Perhaps you are spending too much time on homework. You might want to reconsider if you have been multi-tasking or becoming distracted!")
                        .foregroundColor(.red.opacity(0.75))
                } else if activity == "enjoyment" && averageHoursOrRating < 1 {
                    Text("It is recommended for you to spend more time doing things that make you happy. Try taking a 15-minute break every once in a while to relax and enjoy yourself!")
                        .foregroundColor(.red.opacity(0.75))
                } else if activity == "" && averageHoursOrRating < 50 {
                    Text("Looks like you've been going through a lot. Please take time to take care of yourself and remember that things will get better.")
                }
                else {
                    Text("Great job! This is a great spot to be in.")
                        .foregroundColor(Color("SecondaryColor"))
                }
            }
            .font(.system(.body, design: .rounded))
            .multilineTextAlignment(.center)
            .padding(.horizontal, 10)
        }
        .standardFrame()
        .shadow(color: Color.gray.opacity(0.5), radius: 10)
        .frame(maxHeight: 275)
        .padding(10)
    }
}

