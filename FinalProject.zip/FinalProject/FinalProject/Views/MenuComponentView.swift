//
//  MenuComponentView.swift
//  FinalProject
//
//  Created by Curtis Yucheng Ying24 on 5/20/23.
//

import SwiftUI

struct MenuComponentView: View {
    //Declare variables and constants
    let smallFrameHeight: CGFloat = 200
    let title: String
    let image: String
    let imageColor: Color
    let description: String
    var body: some View {
        //Template that allows large title with image and a small description below
        VStack (spacing: 10) {
            Text(title)
                .font(.system(.title3, design: .rounded))
                .fontWeight(.semibold)
                .foregroundColor(.black)
                .padding(.horizontal, 10)
            Image(systemName: image)
                .font(.largeTitle)
                .foregroundColor(imageColor)
                .frame(height: 50)
            Text(description)
                .font(.system(.body, design: .rounded))
                .multilineTextAlignment(.center)
                .foregroundColor(.black)
                .padding(.horizontal, 10)
        }
        .standardFrame()
        .shadow(color: Color.white, radius: 10)
        .frame(maxHeight: smallFrameHeight)
    }
}


