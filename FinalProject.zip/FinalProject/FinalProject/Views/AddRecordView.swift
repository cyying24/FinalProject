//
//  AddRecordView.swift
//  FinalProject
//
//  Created by Curtis Yucheng Ying24 on 5/20/23.
//

import SwiftUI

struct AddRecordView: View {
    //Declare variables and constants
    @ObservedObject var healthTrackerViewModel: HealthTrackerViewModel
    @State var date: Date = Date()
    @State var sleepHours: Double = 0
    @State var exerciseHours: Double = 0
    @State var homeworkHours: Double = 0
    @State var enjoymentHours: Double = 0
    @State var overallRating: Double = 50
    @State var notes: String = ""
    @State var showAlert: Bool = false
    @Environment (\.presentationMode) var presentationMode
    
    var body: some View {
        //Different sections separated by a gap in between
        VStack {
            Text("Log Your Day")
                .font(.system(.title2, design: .rounded))
                .bold()
            Form {
                Section {
                    //Allows user to pick a date that is in the past and sets the "date" variable to that date
                    DatePicker(
                        "Date",
                        selection: $date,
                        in: ...Date(),
                        //Only displays the date since time is not important/used
                        displayedComponents: [.date]
                    )
                }
                
                Section {
                    Text("How much sleep did you get?")
                        .font(.system(.body, design: .rounded))
                    //Displays hours to 2 decimal points
                    Text(String(format: "%.2f Hours", sleepHours))
                        .fontWeight(.semibold)
                        .foregroundColor(.blue)
                        .font(.system(.body, design: .rounded))
                    //User can set hour values by quarter-hour increments up to 24 hours
                    Slider(value: $sleepHours, in: 0...24, step: 0.25)
                        .accentColor(.blue)
                        .font(.system(.body, design: .rounded))
                }
                
                Section {
                    Text("How long did you exercise?")
                    Text(String(format: "%.2f Hours", exerciseHours))
                        .fontWeight(.semibold)
                        .foregroundColor(.blue)
                    Slider(value: $exerciseHours, in: 0...24, step: 0.25)
                        .accentColor(.blue)
                }
                
                Section {
                    Text("How long did you do homework?")
                    Text(String(format: "%.2f Hours", homeworkHours))
                        .fontWeight(.semibold)
                        .foregroundColor(.blue)
                    Slider(value: $homeworkHours, in: 0...24, step: 0.25)
                        .accentColor(.blue)
                }
                
                Section {
                    Text("How long did you get to have fun or enjoy yourself?")
                    Text(String(format: "%.2f Hours", enjoymentHours))
                        .fontWeight(.semibold)
                        .foregroundColor(.blue)
                    Slider(value: $enjoymentHours, in: 0...24, step: 0.25)
                        .accentColor(.blue)
                }
                
                Section {
                    Text("How would you rate the day overall on a scale of 0-100?")
                    HStack {
                        Text(String(Int(overallRating)))
                            .fontWeight(.semibold)
                        //Changes text color based on the color outputted by the function ratingTextAndColor, meant to visually represent how the day rating based on its rating score. Higher ratings mean more "positive" colors.
                            .foregroundColor(healthTrackerViewModel.ratingTextAndColor(rating: overallRating).1)
                        Text("out of 100")
                            .fontWeight(.semibold)
                        Spacer()
                        //Changes the corresponding text and its color based on its day rating. Higher ratings mean a "better" one-word description of the day.
                        Text(healthTrackerViewModel.ratingTextAndColor(rating: overallRating).0)
                            .foregroundColor(healthTrackerViewModel.ratingTextAndColor(rating: overallRating).1)
                            .fontWeight(.semibold)
                    }
                    //User determines value on a scale of 0-100. The color of the slider also changes depending on the day rating.
                    Slider(value: $overallRating, in: 0...100, step: 1)
                        .accentColor(healthTrackerViewModel.ratingTextAndColor(rating: overallRating).1)
                }
                
                Section {
                    Text("Notes (optional)")
                    TextField("Type here...", text: $notes)
                }
            }
            .font(.system(.body, design: .rounded))
            .navigationBarItems(
                trailing: Button ("Save") {
                    //Create a date formatter so that the time component can be ignored. Time is not used; only the day matters. .short makes the date the shortest which is more efficient since the converted date is only used behind the scenes
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateStyle = .short
                    //Checks if there is an existing same date in the struct already. If there is, raises the alert that a second review of the day cannot be submitted
                    if let dateExists = healthTrackerViewModel.healthHistory.firstIndex(where:
                                                                                            {dateFormatter.string(from: $0.date) == dateFormatter.string(from: date)}) {
                        showAlert = true
                    //Checks if the total number of hours "doing stuff" exceeds 24 hours. Given that most people sleep around the same time each day and have things to do besides sleep, exercise, homework, and enjoyment, a total of more than 24 hours means that this is impossible
                    } else if sleepHours + exerciseHours + homeworkHours + enjoymentHours > 24 || sleepHours + exerciseHours + homeworkHours + enjoymentHours == 0 {
                        showAlert = true
                    //Inserts into the struct such that the data is ordered by date, with the most recent day reviews at the bottom. Checks using the time interval since 1970 as an easy way and defaults to 0 when there are no other items in the struct
                    } else {
                        healthTrackerViewModel.healthHistory.insert(HealthRecord(date: date, sleepHours: sleepHours, exerciseHours: exerciseHours, homeworkHours: homeworkHours, enjoymentHours: enjoymentHours, overallRating: Int(overallRating), notes: notes), at: healthTrackerViewModel.healthHistory.firstIndex(where: {$0.date.timeIntervalSince1970 > date.timeIntervalSince1970}) ?? 0)

                        //Close the view
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            )
            .font(.system(.body, design: .rounded))
            .alert(isPresented: $showAlert, content: getAlert)
        }
    }
    //If the total hours is impossible, returns the alert that there are too many hours. Otherwise, it returns the alert that the date already exists (which is the only other possible problem)
    func getAlert() -> Alert {
        if sleepHours + exerciseHours + homeworkHours + enjoymentHours > 24 {
            return Alert(title: Text("Your total hours doing things exceeds 24 hours!"))
        } else if sleepHours + exerciseHours + homeworkHours + enjoymentHours == 0 {
            return Alert(title: Text("Your total hours doing things is zero!"))
        }
        return Alert(title: Text("You already filled out a review of this date!"))
    }
}


