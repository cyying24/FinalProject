//
//  ContentView.swift
//  FinalProject
//
//  Created by Curtis Yucheng Ying24 on 5/20/23.
//

import SwiftUI

struct HealthTrackerView: View {
    //Declare variables and constants
    @StateObject var healthTrackerViewModel = HealthTrackerViewModel()
    @State var dataIsReversed: Bool = false
    let standardRadius: CGFloat = 10
    let smallFrameHeight: CGFloat = 200
    let largeFrameHeight: CGFloat = 450
    var body: some View {
        NavigationView {
            ZStack {
                //Striped background
                Image("StripesBackground")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .ignoresSafeArea()
                VStack {
                    HStack {
                        //Heart and overlayed "+" to create logo
                        ZStack {
                            Image(systemName: "heart.fill")
                                .font(.largeTitle)
                                .foregroundColor(.red)
                                .bold()
                            Image(systemName: "plus")
                                .font(.subheadline)
                                .bold()
                                .foregroundColor(.white)
                        }
                        //Title
                        Text("Me-Meter™")
                            .font(.system(.largeTitle, design: .rounded))
                            .bold()
                            .foregroundColor(.white)
                    }
                    //Short subtitle
                    Text("Check in on yourself!")
                        .font(.system(.subheadline, design: .rounded))
                        .foregroundColor(.white)
                        .fontWeight(.semibold)
                    
                    
                    HStack {
                        //Link to AddRecordView, uses MenuComponentView to minimize repeated code
                        NavigationLink(
                            destination:
                                //Links to AddRecordView and passes along the view model
                                AddRecordView(healthTrackerViewModel: healthTrackerViewModel),
                            label: {
                                MenuComponentView(title: "Log Your Day", image: "chart.bar.doc.horizontal", imageColor: Color.blue, description: "Time to take a look at your day!")
                                    .padding(.horizontal,3)
                            }
                        )
                        
                        //Link to StatisticsView, uses MenuComponentView, but does not show and is "locked" when there are no data to show statistics for
                        if healthTrackerViewModel.healthHistory.count != 0 {
                            NavigationLink(
                                destination: StatisticsView(healthTrackerViewModel: healthTrackerViewModel),
                                label: {
                                    MenuComponentView(title: "Your Statistics", image: "chart.line.uptrend.xyaxis", imageColor: Color("SecondaryColor"), description: "See how you've been doing lately!")
                                        .padding(.horizontal,3)
                                }
                            )
                        } else {
                            //Implements NoRecordView instead with the same frame size to show that 1 day must be logged first
                            NoRecordView(height: smallFrameHeight)
                        }
                    }
                    
                    //Insert new VStack to create a new text square, does not use MenuComponentView since there is more than just a description for this box. Does not show up and is "locked" if there are no records to show
                    if healthTrackerViewModel.healthHistory.count != 0 {
                        VStack {
                            Text("Your Past Logs:")
                                .font(.system(.title3, design: .rounded))
                                .fontWeight(.semibold)
                                .padding(.vertical)
                            //If the data are reversed (if dataIsReversed == true), shows that the dates are reversed (least recent dates are at the top). Defaults to most recent dates at the top
                            HStack {
                                if dataIsReversed == true {
                                    Text("Date (Reversed)")
                                        .font(.system(.callout, design: .rounded))
                                        .frame(maxWidth: .infinity, alignment: .center)
                                        .fontWeight(.medium)
                                } else {
                                    Text("Date")
                                        .font(.system(.callout, design: .rounded))
                                        .frame(maxWidth: .infinity, alignment: .center)
                                        .fontWeight(.medium)
                                }
                                
                                Text("Day Rating")
                                    .font(.system(.callout, design: .rounded))
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .fontWeight(.medium)
                                //Toggles the dataIsReversed value and reverses order of the data
                                Button {
                                    healthTrackerViewModel.healthHistory.reverse()
                                    dataIsReversed.toggle()
                                } label: {
                                    Image(systemName: "arrow.2.circlepath.circle.fill")
                                        .foregroundColor(.orange)
                                        .font(.title2)
                                }
                                .padding(.horizontal, 3)
                                
                            }
                            //Inserts horizontal line to separate title from data
                            Divider()
                                .frame(width: 350, height: 0.5)
                                .overlay(.black)
                            ScrollView {
                                //Reverses the data struct to print most recent entries at the top to minimize scrolling
                                ForEach(healthTrackerViewModel.healthHistory.reversed(), id: \.self) { record in
                                    //In data row, prints date being reviewed and its rating, uses RecordRowView and each row is a link to its respective EditRecordView
                                    HStack {
                                        Text(record.date, format: .dateTime.weekday().day().month().year())
                                            .font(.system(.subheadline, design: .rounded))
                                            .frame(maxWidth: .infinity, alignment: .center)
                                        Text(String(record.overallRating))
                                            .font(.system(.subheadline, design: .rounded))
                                            .frame(maxWidth: .infinity, alignment: .center)
                                        //Button that leads to EditRecordView
                                        NavigationLink(destination: EditRecordView(healthTrackerViewModel: healthTrackerViewModel, editableRecord: record))
                                        {
                                            Image(systemName: "square.and.pencil.circle.fill")
                                                .font(.title2)
                                        }
                                        .padding(.horizontal, 3)
                                    }
                                    .padding(.vertical, 1)
                                }
                            }
                        }
                        .frame(height: largeFrameHeight)
                        .background(Color.white)
                        .cornerRadius(standardRadius)
                        .shadow(color: Color.white, radius: standardRadius)
                    } else {
                        //Replaced with NoRecordView to show that the log is locked until 1 day has been recorded
                        NoRecordView(height: largeFrameHeight)
                    }
                    Spacer()
                }
                .padding()
            }
        }
    }
}

struct HealthTrackerView_Previews: PreviewProvider {
    static var previews: some View {
        HealthTrackerView()
    }
}
