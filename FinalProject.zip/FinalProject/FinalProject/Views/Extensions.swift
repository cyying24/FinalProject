//
//  Extensions.swift
//  FinalProject
//
//  Created by Curtis Yucheng Ying24 on 5/23/23.
//

import SwiftUI

//Extension for the frames on the home screen and the statistics tab. Rounds the corners and creates the frame and background color
extension VStack {
    func standardFrame() -> some View {
        self
            .padding(.vertical)
            .frame(maxWidth: .infinity)
            .background(Color.white)
            .cornerRadius(10)
    }
}
