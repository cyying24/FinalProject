//
//  NoRecordView.swift
//  FinalProject
//
//  Created by Curtis Yucheng Ying24 on 5/23/23.
//

import SwiftUI

struct NoRecordView: View {
    //Declare variables and constants
    let height: CGFloat
    var body: some View {
        VStack {
            Image(systemName: "lock.fill")
                .foregroundColor(.white)
                .font(.title)
                .padding()
            //Makes the text bigger if there is more room for it (if the height is larger than 200)
            if height > 200 {
                Text("Unlock this after logging 1 day!")
                    .foregroundColor(.white)
                    .font(.system(.title3, design: .rounded))
            } else {
                Text("Unlock this after logging 1 day!")
                    .foregroundColor(.white)
                    .font(.system(.subheadline, design: .rounded))
            }
        }
        //Decrease the maxHeight by a little so that the size ends up fitting with the desired frame
        .frame(maxWidth: .infinity, maxHeight: height - 25)
        .background(Color.black.opacity(0.8))
        .cornerRadius(10)
        .multilineTextAlignment(.center)
    }
}


