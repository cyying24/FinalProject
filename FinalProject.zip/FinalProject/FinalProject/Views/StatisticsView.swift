//
//  StatisticsView.swift
//  FinalProject
//
//  Created by Curtis Yucheng Ying24 on 5/21/23.
//

import SwiftUI

struct StatisticsView: View {
    //Declare variables and constants
    @ObservedObject var healthTrackerViewModel: HealthTrackerViewModel
    let statisticTimeFilters: [String] = ["Last Week","Last 30 Days","All Time"]
    @State var selectedTimeFilter: String = "Last Week"
    var body: some View {
        VStack {
            Text("Your Statistics")
                .font(.system(.title2, design: .rounded))
                .bold()
            HStack {
                Text("Filter By:")
                    .fontWeight(.semibold)
                //Picker that defaults first to "Last Week" but allows selection of last week, 30 days, or all time
                Picker("Statistic Filters", selection: $selectedTimeFilter,
                       content: {
                    ForEach(statisticTimeFilters.indices) { index in
                        Text(statisticTimeFilters[index])
                            .tag(statisticTimeFilters[index])
                    }
                })
                .bold()
            }
            .font(.system(.body, design: .rounded))
            
            ScrollView {
                //For each filter, lists multiple StatisticsComponentViews that each give a statistic on one factor (hours of sleep, etc.). Since each filter cannot be directly substituted into the subview and a different category is needed for each box (sleep, homework, etc.), there is no "clean" way to only have the subview a few times.
                if selectedTimeFilter == "Last Week" {
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "face.smiling", imageColor: Color.yellow.opacity(0.5), activity: "", averageHoursOrRating: Double(healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 7).reduce(0, {$0 + $1.overallRating}))/Double(healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 7).count))
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "bed.double", imageColor: Color("SecondaryColor"), activity: "sleep", averageHoursOrRating: healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 7).reduce(0, {$0 + $1.sleepHours})/Double(healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 7).count))
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "figure.run", imageColor: Color.orange, activity: "exercise", averageHoursOrRating: healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 7).reduce(0, {$0 + $1.exerciseHours})/Double(healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 7).count))
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "doc.richtext", imageColor: Color.blue, activity: "homework", averageHoursOrRating: healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 7).reduce(0, {$0 + $1.homeworkHours})/Double(healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 7).count))
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "play.desktopcomputer", imageColor: Color.red, activity: "enjoyment", averageHoursOrRating: healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 7).reduce(0, {$0 + $1.enjoymentHours})/Double(healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 7).count))
                    
                } else if selectedTimeFilter == "Last 30 Days" {
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "face.smiling", imageColor: Color.yellow.opacity(0.5), activity: "", averageHoursOrRating: Double(healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 30).reduce(0, {$0 + $1.overallRating}))/Double(healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 30).count))
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "bed.double", imageColor: Color("SecondaryColor"), activity: "sleep", averageHoursOrRating: healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 30).reduce(0, {$0 + $1.sleepHours})/Double(healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 30).count))
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "figure.run", imageColor: Color.orange, activity: "exercise", averageHoursOrRating: healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 30).reduce(0, {$0 + $1.exerciseHours})/Double(healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 30).count))
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "doc.richtext", imageColor: Color.blue, activity: "homework", averageHoursOrRating: healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 30).reduce(0, {$0 + $1.homeworkHours})/Double(healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 30).count))
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "play.desktopcomputer", imageColor: Color.red, activity: "enjoyment", averageHoursOrRating: healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 30).reduce(0, {$0 + $1.enjoymentHours})/Double(healthTrackerViewModel.daysAgoHistoryFilter(startDaysAgo: 30).count))
                    
                } else {
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "face.smiling", imageColor: Color.yellow.opacity(0.5), activity: "", averageHoursOrRating: Double(healthTrackerViewModel.healthHistory.reduce(0, {$0 + $1.overallRating}))/Double(healthTrackerViewModel.healthHistory.count))
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "bed.double", imageColor: Color("SecondaryColor"), activity: "sleep", averageHoursOrRating: healthTrackerViewModel.healthHistory.reduce(0, {$0 + $1.sleepHours})/Double(healthTrackerViewModel.healthHistory.count))
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "figure.run", imageColor: Color.orange, activity: "exercise", averageHoursOrRating: healthTrackerViewModel.healthHistory.reduce(0, {$0 + $1.exerciseHours})/Double(healthTrackerViewModel.healthHistory.count))
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "doc.richtext", imageColor: Color.blue, activity: "homework", averageHoursOrRating: healthTrackerViewModel.healthHistory.reduce(0, {$0 + $1.homeworkHours})/Double(healthTrackerViewModel.healthHistory.count))
                    
                    StatisticsComponentView(selectedTimeFilter: selectedTimeFilter, image: "play.desktopcomputer", imageColor: Color.red, activity: "enjoyment", averageHoursOrRating: healthTrackerViewModel.healthHistory.reduce(0, {$0 + $1.enjoymentHours})/Double(healthTrackerViewModel.healthHistory.count))
                    
                }
            }
            
            Spacer()
        }
        .font(.system(.body, design: .rounded))
    }
}

