//
//  EditRecordView.swift
//  FinalProject
//
//  Created by Curtis Yucheng Ying24 on 5/20/23.
//

import SwiftUI

struct EditRecordView: View {
    //Declare variables
    @ObservedObject var healthTrackerViewModel: HealthTrackerViewModel
    @State var editableRecord: HealthRecord
    @State var date: Date = Date()
    @State var sleepHours: Double = 0.0
    @State var exerciseHours: Double = 0.0
    @State var homeworkHours: Double = 0.0
    @State var enjoymentHours: Double = 0.0
    @State var overallRating: Double = 0.0
    @State var notes: String = ""
    @State var showAlert: Bool = false
    @Environment (\.presentationMode) var presentationMode
    var body: some View {
        //Different sections separated by a gap in between
        VStack {
            Text("Log Your Day")
                .font(.system(.title2, design: .rounded))
                .bold()
            Form {
                Section {
                    //Allows user to pick a date that is in the past and sets the "date" variable to that date
                    DatePicker(
                        "Date",
                        selection: $date,
                        in: ...Date(),
                        //Only displays the date since time is not important/used
                        displayedComponents: [.date]
                    )
                }
                
                Section {
                    Text("How much sleep did you get?")
                        .font(.system(.body, design: .rounded))
                    //Displays hours to 2 decimal points
                    Text(String(format: "%.2f Hours", sleepHours))
                        .fontWeight(.semibold)
                        .foregroundColor(.blue)
                        .font(.system(.body, design: .rounded))
                    //User can set hour values by quarter-hour increments up to 24 hours
                    Slider(value: $sleepHours, in: 0...24, step: 0.25)
                        .accentColor(.blue)
                        .font(.system(.body, design: .rounded))
                }
                
                Section {
                    Text("How long did you exercise?")
                    Text(String(format: "%.2f Hours", exerciseHours))
                        .fontWeight(.semibold)
                        .foregroundColor(.blue)
                    Slider(value: $exerciseHours, in: 0...24, step: 0.25)
                        .accentColor(.blue)
                }
                
                Section {
                    Text("How long did you do homework?")
                    Text(String(format: "%.2f Hours", homeworkHours))
                        .fontWeight(.semibold)
                        .foregroundColor(.blue)
                    Slider(value: $homeworkHours, in: 0...24, step: 0.25)
                        .accentColor(.blue)
                }
                
                Section {
                    Text("How long did you get to have fun or enjoy yourself?")
                    Text(String(format: "%.2f Hours", enjoymentHours))
                        .fontWeight(.semibold)
                        .foregroundColor(.blue)
                    Slider(value: $enjoymentHours, in: 0...24, step: 0.25)
                        .accentColor(.blue)
                }
                
                Section {
                    Text("How would you rate the day overall on a scale of 0-100?")
                    HStack {
                        Text(String(Int(overallRating)))
                            .fontWeight(.semibold)
                        //Changes text color based on the color outputted by the function ratingTextAndColor, meant to visually represent how the day rating based on its rating score. Higher ratings mean more "positive" colors.
                            .foregroundColor(healthTrackerViewModel.ratingTextAndColor(rating: overallRating).1)
                        Text("out of 100")
                            .fontWeight(.semibold)
                        Spacer()
                        //Changes the corresponding text and its color based on its day rating. Higher ratings mean a "better" one-word description of the day.
                        Text(healthTrackerViewModel.ratingTextAndColor(rating: overallRating).0)
                            .foregroundColor(healthTrackerViewModel.ratingTextAndColor(rating: overallRating).1)
                            .fontWeight(.semibold)
                    }
                    //User determines value on a scale of 0-100. The color of the slider also changes depending on the day rating.
                    Slider(value: $overallRating, in: 0...100, step: 1)
                        .accentColor(healthTrackerViewModel.ratingTextAndColor(rating: overallRating).1)
                }
                
                Section {
                    Text("Notes (optional)")
                    TextField("Type here...", text: $notes)
                }
            }
            .font(.system(.body, design: .rounded))
            .navigationBarItems(
                trailing: Button ("Save") {
                    //Create a date formatter so that the time component can be ignored. Time is not used; only the day matters. .short makes the date the shortest which is more efficient since the converted date is only used behind the scenes
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateStyle = .short
                    if sleepHours + exerciseHours + homeworkHours + enjoymentHours > 24 || sleepHours + exerciseHours + homeworkHours + enjoymentHours == 24{
                        showAlert = true
                    //Inserts into the struct such that the data is ordered by date, with the most recent day reviews at the bottom. Checks using the time interval since 1970 as an easy way and defaults to 0 when there are no other items in the struct
                    } else {
                        if let recordIndex = healthTrackerViewModel.healthHistory.firstIndex(where:
                                                                                    {$0.id == editableRecord.id})  {
                            healthTrackerViewModel.healthHistory[recordIndex].sleepHours = sleepHours
                            healthTrackerViewModel.healthHistory[recordIndex].exerciseHours = exerciseHours
                            healthTrackerViewModel.healthHistory[recordIndex].homeworkHours = homeworkHours
                            healthTrackerViewModel.healthHistory[recordIndex].enjoymentHours = enjoymentHours
                            healthTrackerViewModel.healthHistory[recordIndex].overallRating = Int(overallRating)
                            healthTrackerViewModel.healthHistory[recordIndex].notes = notes
                            
                        }

                        //Close the view
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            )
            .font(.system(.body, design: .rounded))
            .alert(isPresented: $showAlert, content: impossibleAlert)
        }
        .onAppear {
            date = editableRecord.date
            sleepHours = editableRecord.sleepHours
            exerciseHours = editableRecord.exerciseHours
            homeworkHours = editableRecord.homeworkHours
            enjoymentHours = editableRecord.enjoymentHours
            overallRating = Double(editableRecord.overallRating)
            notes = editableRecord.notes
        }
    }
    //If the total hours is impossible, returns the alert that there are too many hours or zero hours.
    func impossibleAlert() -> Alert {
        if sleepHours + exerciseHours + homeworkHours + enjoymentHours > 24 {
            return Alert(title: Text("Your total hours doing things exceeds 24 hours!"))
        } else {
            return Alert(title: Text("Your total hours doing things is zero!"))
        }
    }
}
