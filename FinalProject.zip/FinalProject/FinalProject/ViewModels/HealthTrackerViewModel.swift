//
//  HealthTrackerViewModel.swift
//  FinalProject
//
//  Created by Curtis Yucheng Ying24 on 5/20/23.
//

import Foundation
import SwiftUI

//Allows HealthRecord struct to be accessible in any other file
class HealthTrackerViewModel: ObservableObject {
    @Published var healthHistory : [HealthRecord] = []
    
    //Function using nested conditionals that returns text and text color based on the rating of the day. Lower ratings return more negative comments and colors, whereas higher ratings return more positive comments and colors
    func ratingTextAndColor(rating: Double) -> (String, Color) {
        if rating <= 20 {
            return ("Horrible! 😔", Color.red)
        } else if rating <= 40 {
            return ("Bad 🙁", Color.orange)
        } else if rating <= 60 {
            return ("Okay 😐", Color.yellow)
        } else if rating <= 80 {
            return ("Good 🙂", Color.green)
        } else {
            return ("Amazing! 😄", Color.purple)
        }
    }
    
    //Function that filters the struct data for those that fall within a specific number of days of the current time
    func daysAgoHistoryFilter(startDaysAgo: Int) -> [HealthRecord] {
        //Sets the range of possible dates as ___ days ago to now
        let dateRange = (Calendar.current.date(byAdding: .day, value: -1 * startDaysAgo, to: Date())!)...Date()
        //Returns only the data that fall in the range
        return healthHistory.filter({dateRange.contains($0.date)})
    }
}
