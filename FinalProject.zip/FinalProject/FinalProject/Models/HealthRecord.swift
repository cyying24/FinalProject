//
//  HealthTracker.swift
//  FinalProject
//
//  Created by Curtis Yucheng Ying24 on 5/20/23.
//

import Foundation

//Struct that contains a UUID (to make its ID unique so there are no repeats), date, hours of sleep, hours of exercise, hours of homework, hours of enjoyment, overall rating, and notes. Is Identifiable so it can be referenced in other files and Hashable so it can be iterated
struct HealthRecord: Identifiable, Hashable {
    var id = UUID()
    var date: Date
    var sleepHours: Double
    var exerciseHours: Double
    var homeworkHours: Double
    var enjoymentHours: Double
    var overallRating: Int
    var notes: String
}
