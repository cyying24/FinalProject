//
//  FinalProjectApp.swift
//  FinalProject
//
//  Created by Curtis Yucheng Ying24 on 5/20/23.
//

import SwiftUI

@main
struct FinalProjectApp: App {
    var body: some Scene {
        WindowGroup {
            HealthTrackerView()
        }
    }
}
